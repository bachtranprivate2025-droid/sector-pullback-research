"""SPY MA-pullback -> sector basket engine (rebuild of sector-pullback-research rules)."""
import numpy as np, pandas as pd

SECT = ['XLB', 'XLC', 'XLE', 'XLF', 'XLI', 'XLK', 'XLP', 'XLRE', 'XLU', 'XLV', 'XLY']
FEE = 0.001


def load(path):
    d = pd.read_csv(path, parse_dates=['date'], encoding='utf-8-sig')
    P = {k: d.pivot(index='date', columns='symbol', values=k) for k in ['open', 'high', 'low', 'close']}
    idx = P['close']['SPY'].dropna().index
    P = {k: v.reindex(idx) for k, v in P.items()}
    return P


def wilder_atr(h, l, c, n=14):
    tr = pd.concat([h - l, (h - c.shift()).abs(), (l - c.shift()).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1 / n, adjust=False).mean()


def ma_series(c, kind, n):
    """MA known before session t (daily: prior close SMA; weekly: closed weeks before this week)."""
    if kind == 'D':
        return c.rolling(n).mean().shift(1)
    wk = c.groupby(c.index.to_period('W-FRI')).last()
    wma = wk.rolling(n).mean()
    per = c.index.to_period('W-FRI')
    prev = wma.shift(1)  # MA of weeks strictly before current week
    return pd.Series(prev.reindex(per).values, index=c.index)


def signals(P, kind, n, width, conf, rearm=3, reclaim_max=5):
    """Return boolean array of signal days (decision at close of that day)."""
    c, h, l = P['close']['SPY'], P['high']['SPY'], P['low']['SPY']
    ma = ma_series(c, kind, n).values
    atr = wilder_atr(h, l, c).shift(1).values
    up = ma + width * atr
    L, C = l.values, c.values
    N = len(c)
    sig = np.zeros(N, bool)
    armed, above = False, 0
    pend = -1  # index of touch awaiting reclaim
    for t in range(N):
        if np.isnan(up[t]):
            continue
        if pend >= 0:
            if C[t] >= ma[t]:
                sig[t] = True
                pend = -1
            elif t - pend >= reclaim_max:
                pend = -1
        if L[t] > up[t]:
            above += 1
            if above >= rearm:
                armed = True
            continue
        above = 0
        if armed:  # touch from above: prior close must sit above today's known zone
            armed = False
            if t == 0 or C[t - 1] <= up[t]:
                continue
            if conf == 'touch':
                sig[t] = True
            elif conf == 'hold':
                if C[t] >= ma[t]:
                    sig[t] = True
            elif conf == 'reclaim':
                if C[t] >= ma[t]:
                    sig[t] = True
                else:
                    pend = t
    return sig


def prep(P):
    c = P['close']
    elig = c[SECT].notna().cumsum().shift(1) >= 200  # >=200 closed sessions before t
    perf = {k: c[SECT] / c[SECT].shift(k) - 1 for k in (3, 20, 60, 250)}
    sma200 = c[SECT].rolling(200).mean()
    return dict(elig=elig, perf=perf, sma200=sma200)


def pick(D, P, t, policy):
    """tickers chosen at close of index t."""
    e = D['elig'].iloc[t]
    names = e.index[e.values]
    if policy == 'SPY':
        return ['SPY']
    pf = D['perf']
    if policy in ('L20', 'L60', 'L250'):
        s = pf[int(policy[1:])].iloc[t][names].dropna()
        return list(s.nlargest(3).index)
    if policy == 'L250T':  # 12M leaders above own SMA200
        s = pf[250].iloc[t][names].dropna()
        ok = P['close'][SECT].iloc[t] > D['sma200'].iloc[t]
        s = s[ok[s.index].values]
        return list(s.nlargest(3).index)
    if policy == 'B3':
        s = pf[20].iloc[t - 1][names].dropna()
        return list(s.nsmallest(3).index)
    if policy == 'BR3':
        s = pf[20].iloc[t - 1][names].dropna()
        b4 = s.nsmallest(4).index
        r3 = pf[3].iloc[t][b4].dropna()
        return list(r3.nlargest(3).index)
    raise ValueError(policy)


def run_fixed(P, D, sig, policy, hold, start, end, allow_same_day=False):
    """Fixed-hold baskets. Returns DataFrame of baskets."""
    idx = P['close'].index
    O, C = P['open'], P['close']
    s0, s1 = idx.searchsorted(start), idx.searchsorted(end, 'right') - 1
    out, busy_until = [], -1
    for t in np.nonzero(sig)[0]:
        if t < s0 or t > s1:
            continue
        if t < busy_until or (t == busy_until and not allow_same_day):
            continue
        ent, ex = t + 1, t + hold
        if ex > s1:
            break
        tk = pick(D, P, t, policy)
        if not tk:
            continue
        r = (C[tk].iloc[ex] / O[tk].iloc[ent] - 1).mean() - FEE
        out.append((idx[t], idx[ent], idx[ex], ','.join(tk), r))
        busy_until = ex
    return pd.DataFrame(out, columns=['signal', 'entry', 'exit', 'tickers', 'ret'])


def stats(r):
    r = np.asarray(r)
    if len(r) == 0:
        return dict(n=0, pf=np.nan, wr=np.nan, avg=np.nan, worst=np.nan)
    neg = -r[r < 0].sum()
    return dict(n=len(r), pf=(r[r > 0].sum() / neg) if neg > 0 else np.nan,
                wr=(r > 0).mean(), avg=r.mean(), worst=r.min())
