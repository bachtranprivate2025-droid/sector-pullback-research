import sys, pickle; sys.path.insert(0,'/home/claude/bt')
from study2 import *
SIG,res=pickle.load(open('res2.pkl','rb'))
US={'sector':U(SECT,9),'sub':U(SUB,10)}
W0=0.25
main_sig=SIG[('D50',W0,'hold')]|SIG[('W10',W0,'hold')]|SIG[('W20',W0,'hold')]
out={}
for name,u in US.items():
    bas=u.run(main_sig,'L250T','SMA5'); r=np.array([b['r'] for b in bas]); n=len(bas)
    obs=pf(r)
    # permutation: random signal days
    days=np.arange(u.s0,u.s1-12)
    rng=np.random.default_rng(11); perm=[]
    for k in range(1000):
        s=np.zeros(u.N,bool); s[rng.choice(days,int(n*1.15),replace=False)]=True
        b=u.run(s,'L250T','SMA5'); rr=np.array([x['r'] for x in b])[:n]
        perm.append(pf(rr))
    perm=np.array(perm)
    # bootstrap
    bs=np.array([pf(rng.choice(r,len(r),replace=True)) for _ in range(5000)])
    out[name]=dict(bas=bas,obs=obs,perm=perm,p=(perm>=obs).mean(),perm_med=np.median(perm),perm95=np.percentile(perm,95),ci=np.percentile(bs,[5,50,95]),eq=u.equity(bas))
    print(name,'n',n,'pf',round(obs,2),'perm median',round(np.median(perm),2),'95%',round(np.percentile(perm,95),2),'p',(perm>=obs).mean(),'boot 5/50/95',np.percentile(bs,[5,50,95]).round(2))
# equal-window comparison 2007-02-22+
us=US['sector']; s0sub=US['sub'].s0
from copy import copy
u2=copy(us); u2.s0=s0sub
b2=u2.run(main_sig,'L250T','SMA5'); r2=[b['r'] for b in b2]
print('sector same window as sub: n',len(r2),'pf',round(pf(r2),2),'avg',round(np.mean(r2)*100,2),'drop3',round(drop3(r2),2))
out['sector_samewin']=dict(n=len(r2),pf=pf(r2),avg=np.mean(r2),drop3=drop3(r2),wr=np.mean(np.array(r2)>0),worst=min(r2))
# also RAND / SPY / B3 same signals
for name,u in US.items():
    for pol in ['SPY','B3','L20','L4K','L250']:
        b=u.run(main_sig,pol,'SMA5'); rr=np.array([x['r'] for x in b])
        out[name][pol]=dict(n=len(rr),pf=pf(rr),wr=(rr>0).mean(),avg=rr.mean(),worst=rr.min(),drop3=drop3(rr),eq=u.equity(b),p1=pf(rr[IDX[[x['t'] for x in b]]<'2009']),p2=pf(rr[(IDX[[x['t'] for x in b]]>='2009')&(IDX[[x['t'] for x in b]]<'2016')]),p3=pf(rr[IDX[[x['t'] for x in b]]>='2016']))
    runs=[]
    for k in range(30):
        b=u.run(main_sig,'RAND','SMA5',np.random.default_rng(500+k)); rr=np.array([x['r'] for x in b]); runs.append((pf(rr),(rr>0).mean(),rr.mean()))
    out[name]['RAND']=dict(pf=np.median([x[0] for x in runs]),wr=np.median([x[1] for x in runs]),avg=np.median([x[2] for x in runs]))
    print(name,{k:(round(v['pf'],2) if isinstance(v,dict) and 'pf' in v else None) for k,v in out[name].items() if isinstance(v,dict)})
pickle.dump(out,open('extra.pkl','wb'))
