import sys, pickle; sys.path.insert(0,'/home/claude/bt')
import numpy as np, pandas as pd
from study2 import pf, drop3, IDX
SIG,res=pickle.load(open('res2.pkl','rb'))
rows=[]
for name,R in res.items():
  for key,bas in R['BAS'].items():
    ma,w,cf,pol,ex=key
    r=np.array([b['r'] for b in bas]); t=np.array([b['t'] for b in bas],int)
    d=IDX[t] if len(t) else pd.DatetimeIndex([])
    from study2 import U
    base=R['BASE'][(pol,ex)]
    yrs=(IDX[R['s1']]-IDX[R['s0']]).days/365.25
    row=dict(univ=name,ma=ma,w=w,conf=cf,pol=pol,exit=ex,n=len(r),per_yr=len(r)/yrs,pf=pf(r),wr=(r>0).mean() if len(r) else np.nan,
      avg=r.mean() if len(r) else np.nan, worst=r.min() if len(r) else np.nan, drop3=drop3(r), pf030=pf(r-0.002),
      mae=np.mean([b['mae'] for b in bas]) if bas else np.nan, mae_worst=min([b['mae'] for b in bas]) if bas else np.nan,
      base_pf=base['pf'], base_avg=base['avg'], edge=(r.mean()-base['avg']) if len(r) else np.nan,
      rand_pf=R['RAND'][(ma,w,cf,ex)][0] if pol!='SPY' else np.nan)
    for lab,a,b in [('p1','1999','2008-12-31'),('p2','2009','2015-12-31'),('p3','2016','2026-12-31'),('pre16','1999','2015-12-31')]:
      m=(d>=a)&(d<=b); row[f'{lab}_n']=int(m.sum()); row[f'{lab}_pf']=pf(r[m])
    # regime
    from study2 import PV
    up=None
    rows.append(row)
df=pd.DataFrame(rows)
# regime split
spy=PV=None
import study2 as S
c=S.PV['close']['SPY']; up=(c>c.rolling(200).mean()).values
reg=[]
for name,R in res.items():
  for key,bas in R['BAS'].items():
    r=np.array([b['r'] for b in bas]); t=np.array([b['t'] for b in bas],int)
    m=up[t] if len(t) else np.array([],bool)
    reg.append(dict(univ=name,ma=key[0],w=key[1],conf=key[2],pol=key[3],exit=key[4],up_n=int(m.sum()),up_pf=pf(r[m]) if len(r) else np.nan,up_avg=r[m].mean() if m.sum() else np.nan,dn_n=int((~m).sum()),dn_pf=pf(r[~m]) if len(r) else np.nan,dn_avg=r[~m].mean() if (~m).sum() else np.nan))
df=df.merge(pd.DataFrame(reg),on=['univ','ma','w','conf','pol','exit'])
df.to_pickle('grid.pkl'); df.to_csv('grid.csv',index=False)
print(len(df))
