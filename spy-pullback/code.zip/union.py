import sys, pickle; sys.path.insert(0,'/home/claude/bt')
from study2 import *
SIG,res=pickle.load(open('res2.pkl','rb'))
US={'sector':U(SECT,9),'sub':U(SUB,10)}
def summ(u,bas):
    r=np.array([b['r'] for b in bas]); t=np.array([b['t'] for b in bas]); d=IDX[t]
    eq=u.equity(bas); yrs=(IDX[u.s1]-IDX[u.s0]).days/365.25
    dd=(eq/np.maximum.accumulate(eq)-1).min()
    days=sum(b['exi']-b['ent']+1 for b in bas)
    o=dict(n=len(r),per_yr=len(r)/yrs,pf=pf(r),wr=(r>0).mean(),avg=r.mean(),worst=r.min(),drop3=drop3(r),pf030=pf(r-0.002),
           cagr=eq[-1]**(1/yrs)-1,mdd=dd,expo=days/(u.s1-u.s0+1),mult=eq[-1])
    for lab,a,b in [('p1','1999','2008-12-31'),('p2','2009','2015-12-31'),('p3','2016','2026-12-31')]:
        m=(d>=a)&(d<=b); o[lab+'_n']=int(m.sum()); o[lab+'_pf']=pf(r[m])
    up=u.spy_up[t]; o['up_pf']=pf(r[up]); o['dn_pf']=pf(r[~up]); o['dn_n']=int((~up).sum())
    return o
rows=[]
for name,u in US.items():
  for w in [0,0.25,0.5,0.75]:
    for cf in ['hold','reclaim','touch']:
      s=SIG[('D50',w,cf)]|SIG[('W10',w,cf)]|SIG[('W20',w,cf)]
      for pol in ['L250T','L250','L4K','L20','SPY','B3']:
        for ex in ['SMA5','H5','H10','H20']:
          bas=u.run(s,pol,ex); o=summ(u,bas); o.update(univ=name,w=w,conf=cf,pol=pol,exit=ex); rows.append(o)
R=pd.DataFrame(rows); R.to_pickle('union.pkl')
pd.set_option('display.width',250); pd.set_option('display.max_columns',40); pd.set_option('display.max_rows',200)
c=['univ','w','conf','pol','exit','n','per_yr','pf','wr','avg','worst','drop3','pf030','p1_pf','p2_pf','p3_pf','up_pf','dn_pf','dn_n','cagr','mdd','expo']
print(R[(R.conf=='hold')&(R.exit=='SMA5')][c].round(3).to_string())
print(R[(R.conf=='hold')&(R.pol=='L250T')][c].round(3).to_string())
for name,u in US.items():
  c0=u.C[u.s0:u.s1+1,0]; yrs=(IDX[u.s1]-IDX[u.s0]).days/365.25
  print(name,'SPY B&H cagr',(c0[-1]/c0[0])**(1/yrs)-1,'mdd',(c0/np.maximum.accumulate(c0)-1).min())
