"""Universe-parametric SPY-pullback study (Yahoo adjusted daily, 1999-2026)."""
import sys
sys.path.insert(0, '/home/claude/bt')
import numpy as np, pandas as pd
import engine as E

FEE = 0.001
SECT = ['XLB', 'XLC', 'XLE', 'XLF', 'XLI', 'XLK', 'XLP', 'XLRE', 'XLU', 'XLV', 'XLY']
SUB = ['SMH', 'IGV', 'SKYY', 'CIBR', 'XBI', 'IHI', 'IHF', 'PJP', 'KRE', 'IAI', 'XAR', 'IYT', 'JETS',
       'XOP', 'OIH', 'XME', 'PBJ', 'ONLN', 'PEJ', 'IYZ', 'IDU', 'IYR']
FAMILY = {'SKYY': 'IGV', 'JETS': 'IYT'}  # same research family -> max one per basket
PARENT = {'SMH': 'XLK', 'IGV': 'XLK', 'SKYY': 'XLK', 'CIBR': 'XLK', 'XBI': 'XLV', 'IHI': 'XLV', 'IHF': 'XLV',
          'PJP': 'XLV', 'KRE': 'XLF', 'IAI': 'XLF', 'XAR': 'XLI', 'IYT': 'XLI', 'JETS': 'XLI', 'XOP': 'XLE',
          'OIH': 'XLE', 'XME': 'XLB', 'PBJ': 'XLP', 'ONLN': 'XLY', 'PEJ': 'XLY', 'IYZ': 'XLC', 'IDU': 'XLU', 'IYR': 'XLRE'}

RAW = pd.read_csv('/home/claude/bt/ohlc_all.csv', parse_dates=['date'])
PV = {k: RAW.pivot(index='date', columns='symbol', values=k) for k in ['open', 'high', 'low', 'close', 'volume']}
IDX = PV['close']['SPY'].dropna().index
PV = {k: v.reindex(IDX) for k, v in PV.items()}
PSPY = {k: PV[k] for k in ['open', 'high', 'low', 'close']}  # for E.signals (uses SPY columns only)
EXITS = {'H3': ('fix', 3), 'H5': ('fix', 5), 'H10': ('fix', 10), 'H20': ('fix', 20),
         'SMA5': ('sma5', 10), 'H5S': ('stop', 5)}


class U:
    def __init__(self, members, min_elig, end=None):
        self.SYM = ['SPY'] + members
        g = lambda k: PV[k][self.SYM].values
        self.O, self.H, self.L, self.C, self.V = g('open'), g('high'), g('low'), g('close'), g('volume')
        C = self.C
        self.N = len(IDX)
        cnt = np.cumsum(~np.isnan(C), axis=0)
        dv = pd.DataFrame(C * self.V).rolling(20).mean().shift(1).values
        el = np.vstack([np.zeros((1, C.shape[1]), bool), cnt[:-1] >= 200]) & (np.nan_to_num(dv) >= 1e6)
        el[:, 0] = False
        self.ELIG = el
        self.PF = {}
        for k in (3, 5, 20, 21, 60, 63, 126, 250):
            a = np.full_like(C, np.nan); a[k:] = C[k:] / C[:-k] - 1; self.PF[k] = a
        sma = lambda n: pd.DataFrame(C).rolling(n).mean().values
        self.SMA5, self.SMA200 = sma(5), sma(200)
        pc = np.vstack([C[:1] * np.nan, C[:-1]])
        tr = np.fmax(self.H - self.L, np.fmax(np.abs(self.H - pc), np.abs(self.L - pc)))
        self.ATR = pd.DataFrame(tr).ewm(alpha=1 / 14, adjust=False).mean().values
        self.fam = np.array([FAMILY.get(s, s) for s in self.SYM])
        n_el = el[:, 1:].sum(1)
        self.s0 = int(np.argmax(n_el >= min_elig))
        self.s1 = self.N - 1 if end is None else IDX.searchsorted(end, 'right') - 1
        self.spy_up = C[:, 0] > self.SMA200[:, 0]

    def top(self, cols, score, k=3, asc=False):
        o = np.argsort(score if asc else -score, kind='stable')
        out, seen = [], set()
        for i in o:
            if np.isnan(score[i]): continue
            f = self.fam[cols[i]]
            if f in seen: continue
            seen.add(f); out.append(cols[i])
            if len(out) == k: break
        return np.array(out, int)

    def pick(self, t, pol, rnd=None):
        cols = np.nonzero(self.ELIG[t])[0]
        if pol == 'SPY': return np.array([0])
        if len(cols) < 3: return np.array([], int)
        PF = self.PF
        if pol in ('L20', 'L60', 'L250'):
            return self.top(cols, PF[int(pol[1:])][t, cols])
        if pol == 'L250T':
            s = PF[250][t, cols].copy(); s[~(self.C[t, cols] > self.SMA200[t, cols])] = np.nan
            return self.top(cols, s)
        if pol == 'L4K':
            tot = np.zeros(len(cols))
            for k in (5, 21, 63, 126):
                tot += pd.Series(PF[k][t, cols]).rank().fillna(0).values
            return self.top(cols, tot)
        if pol == 'B3':
            return self.top(cols, PF[20][t - 1, cols], asc=True)
        if pol == 'RAND':
            perm = rnd.permutation(cols)
            return self.top(perm, np.arange(len(perm), dtype=float), asc=True)
        raise ValueError(pol)

    def leg(self, j, ent, mode, hold, stop_k=2.0):
        O, H, L, C, s1 = self.O, self.H, self.L, self.C, self.s1
        e = O[ent, j]
        if mode == 'fix':
            ex = ent + hold - 1
            if ex > s1: return None
            return ex, C[ex, j] / e - 1, L[ent:ex + 1, j].min() / e - 1
        if mode == 'stop':
            stp = e - stop_k * self.ATR[ent - 1, j]; last = ent + hold - 1
            if last > s1: return None
            for k in range(ent, last + 1):
                if k > ent and O[k, j] <= stp:
                    return k, O[k, j] / e - 1, L[ent:k + 1, j].min() / e - 1
                if L[k, j] <= stp:
                    return k, stp / e - 1, L[ent:k + 1, j].min() / e - 1
            return last, C[last, j] / e - 1, L[ent:last + 1, j].min() / e - 1
        if mode == 'sma5':
            last = ent + hold - 1
            for k in range(ent, last + 1):
                if k + 1 > s1: return None
                if C[k, j] > self.SMA5[k, j]:
                    return k + 1, O[k + 1, j] / e - 1, L[ent:k + 2, j].min() / e - 1
            return last, C[last, j] / e - 1, L[ent:last + 1, j].min() / e - 1

    def basket(self, t, pol, ex, rnd=None, fee=FEE):
        tk = self.pick(t, pol, rnd)
        if len(tk) == 0 or t + 1 > self.s1: return None
        mode, hold = EXITS[ex]
        legs = [self.leg(j, t + 1, mode, hold) for j in tk]
        if any(x is None for x in legs): return None
        return dict(t=t, ent=t + 1, exi=max(x[0] for x in legs), tk=[self.SYM[j] for j in tk],
                    legs=[(j, x[0], x[1]) for j, x in zip(tk, legs)],
                    r=float(np.mean([x[1] for x in legs]) - fee), mae=float(np.mean([x[2] for x in legs])))

    def run(self, sig, pol, ex, rnd=None):
        out, busy = [], -1
        for t in np.nonzero(sig)[0]:
            if t < self.s0 or t <= busy: continue
            if t > self.s1: break
            b = self.basket(t, pol, ex, rnd)
            if b is None: continue
            out.append(b); busy = b['exi']
        return out

    def equity(self, bas):
        """daily mark-to-market equity (full capital per basket, cash otherwise)."""
        eq = np.ones(self.N); v = 1.0; last = self.s0
        C, O = self.C, self.O
        for b in bas:
            eq[last:b['ent']] = v
            w = v / len(b['legs'])
            for k in range(b['ent'], b['exi'] + 1):
                val = 0
                for j, xi, r in b['legs']:
                    e = O[b['ent'], j]
                    val += w * ((1 + r) if k >= xi else C[k, j] / e)
                eq[k] = val
            v = v * (1 + b['r']); eq[b['exi']] = v; last = b['exi'] + 1
        eq[last:] = v
        return eq[self.s0:self.s1 + 1]


def pf(r):
    r = np.asarray(r, float)
    if len(r) == 0: return np.nan
    neg = -r[r < 0].sum()
    return r[r > 0].sum() / neg if neg > 0 else np.nan


def drop3(r):
    r = np.sort(np.asarray(r, float))
    return pf(r[:-3]) if len(r) > 3 else np.nan
