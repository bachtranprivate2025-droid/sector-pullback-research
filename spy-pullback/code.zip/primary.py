import sys, pickle; sys.path.insert(0,'/home/claude/bt')
from study2 import *
u=U(SECT,9); C,H,L,O=u.C,u.H,u.L,u.O
sma=lambda a,n: pd.DataFrame(a).rolling(n).mean().values
pc=np.vstack([C[:1]*np.nan,C[:-1]]); TR=np.fmax(H-L,np.fmax(np.abs(H-pc),np.abs(L-pc)))
ATRs=sma(TR,14); S20=sma(C,20); S5=sma(C,5); S200=sma(C,200)
IBS=(C-L)/np.where(H-L>0,H-L,np.nan)
# leaders: top4 by 12M return at last completed month end
me=pd.Series(IDX).groupby(IDX.to_period('M')).max()
mi=IDX.get_indexer(me.values)
lead=np.zeros_like(C,bool); cur=None; j=0
mset=set(mi)
for t in range(u.N):
    if t>0 and (t-1) in mset:
        k=t-1; r12=np.full(12,np.nan)
        if k>=252: r12[1:]=C[k,1:]/C[k-252,1:]-1
        r12[~u.ELIG[k]]=np.nan; r12[0]=np.nan
        ok=np.where(~np.isnan(r12))[0]; cur=ok[np.argsort(-r12[ok])[:4]] if len(ok) else None
    if cur is not None: lead[t,cur]=True
trades=[]; openpos={}
for t in range(u.s0,u.s1):
    # exits
    for j in list(openpos):
        e=openpos[j]; held=t-e['t']
        if C[t,j]>S5[t,j] and t+1<=u.s1:
            trades.append(dict(j=j,t=e['t'],exi=t+1,r=O[t+1,j]/e['px']-1-FEE)); del openpos[j]
        elif held>=10:
            trades.append(dict(j=j,t=e['t'],exi=t,r=C[t,j]/e['px']-1-FEE)); del openpos[j]
    if C[t,0]<=S200[t,0]: continue
    for j in np.where(lead[t])[0]:
        if j in openpos or len(openpos)>=3: continue
        if C[t,j]>S200[t,j] and C[t,j]<S20[t,j]-1.5*ATRs[t,j] and IBS[t,j]<0.25:
            openpos[j]=dict(t=t,px=C[t,j])
T=pd.DataFrame(trades); T['sym']=[u.SYM[j] for j in T.j]; T['date']=IDX[T.t]
r=T.r.values
print('primary all',len(r),round(pf(r),2),'wr',round((r>0).mean(),3),'avg',round(r.mean()*100,2))
for a,b in [('1999','2008-12-31'),('2009','2015-12-31'),('2012','2026-12-31'),('2016','2026-12-31')]:
    m=(T.date>=a)&(T.date<=b); print(a,b,m.sum(),round(pf(r[m]),2))
ex=pickle.load(open('extra.pkl','rb')); bas=ex['sector']['bas']
# overlap: union-basket legs whose ticker had a primary trade open/entered within signal..exit window
pt={(row.j):[] for row in T.itertuples()}
for row in T.itertuples(): pt.setdefault(row.j,[]).append((row.t,row.exi))
ov=0; legs=0; bov=0
for b in bas:
    hit=False
    for j,xi,rr in b['legs']:
        legs+=1
        if any(not (pe < b['t']-2 or ps > b['exi']) for ps,pe in pt.get(j,[])): ov+=1; hit=True
    bov+=hit
print('union legs overlapping primary trades',ov,'/',legs,'baskets with any overlap',bov,'/',len(bas))
# dates overlap: primary trade entries falling inside union basket windows
inside=sum(any(b['t']-2<=row.t<=b['exi'] for b in bas) for row in T.itertuples())
print('primary trades occurring during union baskets',inside,'/',len(T))
pickle.dump(T,open('primary.pkl','wb'))
