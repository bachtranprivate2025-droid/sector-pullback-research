import sys, pickle, json; sys.path.insert(0,'/home/claude/bt')
from study2 import *
SIG,res=pickle.load(open('res2.pkl','rb')); G=pd.read_pickle('grid.pkl'); ex=pickle.load(open('extra.pkl','rb')); T=pickle.load(open('primary.pkl','rb'))
US={'sector':U(SECT,9),'sub':U(SUB,10)}
W0=0.25
def msig(cf,w=W0): return SIG[('D50',w,cf)]|SIG[('W10',w,cf)]|SIG[('W20',w,cf)]
def S(bas,u):
    r=np.array([b['r'] for b in bas]); d=IDX[[b['t'] for b in bas]]
    eq=u.equity(bas); yrs=(IDX[u.s1]-IDX[u.s0]).days/365.25
    o=dict(n=len(r),pf=pf(r),wr=(r>0).mean(),avg=r.mean(),worst=r.min(),drop3=drop3(r),pf030=pf(r-0.002),
      p1=pf(r[d<'2009']),p2=pf(r[(d>='2009')&(d<'2016')]),p3=pf(r[d>='2016']),cagr=eq[-1]**(1/yrs)-1,mdd=(eq/np.maximum.accumulate(eq)-1).min(),
      expo=sum(b['exi']-b['ent']+1 for b in bas)/(u.s1-u.s0+1),mae=np.mean([b['mae'] for b in bas]),maew=min(b['mae'] for b in bas),per_yr=len(r)/yrs)
    up=u.spy_up[[b['t'] for b in bas]]; o['up']=pf(r[up]); o['dn']=pf(r[~up]); o['dn_n']=int((~up).sum())
    return o
J={}
for nm,u in US.items():
    D={}
    # hold period table (main signal, L250T + SPY + RAND-free)
    hp=[]
    for exn in ['H3','H5','H10','H20','SMA5','H5S']:
        b=u.run(msig('hold'),'L250T',exn); s=S(b,u); bs=u.run(msig('hold'),'SPY',exn); s['spy_pf']=pf([x['r'] for x in bs]); s['exit']=exn; s['base']=res[nm]['BASE'][('L250T',exn)]['pf']; hp.append(s)
    D['hold']=hp
    # entry/exit
    ee=[]
    for cf in ['hold','reclaim','touch']:
        for exn in ['SMA5','H5','H5S']:
            b=u.run(msig(cf),'L250T',exn); s=S(b,u); s.update(conf=cf,exit=exn); ee.append(s)
    D['entry']=ee
    # widths
    wd=[]
    for w in [0,0.25,0.5,0.75]:
        b=u.run(msig('hold',w),'L250T','SMA5'); s=S(b,u); s['w']=w; wd.append(s)
    D['width']=wd
    # depth table per MA (hold, w=0.25, SMA5)
    g=G[(G.univ==nm)&(G.conf=='hold')&(G.w==W0)&(G.exit=='SMA5')]
    dep=[]
    for ma in ['D10','D20','D50','W10','W20','D200','W50','W200']:
        x=g[g.ma==ma].set_index('pol')
        dep.append(dict(ma=ma,n=int(x.loc['L250T','n']),L250T=x.loc['L250T','pf'],L250T_d3=x.loc['L250T','drop3'],SPY=x.loc['SPY','pf'],B3=x.loc['B3','pf'],L20=x.loc['L20','pf'],L4K=x.loc['L4K','pf'],RAND=x.loc['L250T','rand_pf'],base=x.loc['L250T','base_pf'],p1=x.loc['L250T','p1_pf'],p2=x.loc['L250T','p2_pf'],p3=x.loc['L250T','p3_pf'],dn=x.loc['L250T','dn_pf']))
    D['depth']=dep
    # MA grid: MA x conf at w=0.25, exit SMA5
    gr=[]
    for ma in ['D10','D20','D50','D200','W10','W20','W50','W200']:
        for cf in ['hold','reclaim','touch']:
            x=G[(G.univ==nm)&(G.ma==ma)&(G.conf==cf)&(G.w==W0)&(G.exit=='SMA5')].set_index('pol')
            pols=['L250T','L250','L4K','L20','SPY','B3']
            best=max(pols,key=lambda p: -1 if np.isnan(x.loc[p,'pf']) else x.loc[p,'pf'])
            gr.append(dict(ma=ma,conf=cf,n=int(x.loc['L250T','n']),pf=x.loc['L250T','pf'],d3=x.loc['L250T','drop3'],spy=x.loc['SPY','pf'],b3=x.loc['B3','pf'],l20=x.loc['L20','pf'],rand=x.loc['L250T','rand_pf'],base=x.loc['L250T','base_pf'],p1=x.loc['L250T','p1_pf'],p3=x.loc['L250T','p3_pf'],best=best))
    D['grid']=gr
    # policy comparison on main signal
    pc=[]
    for pol in ['L250T','L250','L4K','L20','SPY','B3']:
        b=u.run(msig('hold'),pol,'SMA5'); s=S(b,u); s['pol']=pol; pc.append(s)
    pc.append(dict(pol='RAND',**ex[nm]['RAND']))
    D['policy']=pc
    # equity per basket compounding for L250T, SPY, B3 on same signal (same dates)
    eqs={}
    for pol in ['L250T','SPY','B3']:
        b=u.run(msig('hold'),pol,'SMA5'); eqs[pol]=dict(d=[str(IDX[x['t']].date()) for x in b],eq=list(np.cumprod([1+x['r'] for x in b]).round(4)))
    D['eq']=eqs
    # trades
    b=u.run(msig('hold'),'L250T','SMA5')
    D['trades']=[dict(d=str(IDX[x['t']].date()),x=str(IDX[x['exi']].date()),p=' '.join(x['tk']),r=round(x['r']*100,2)) for x in b]
    D['main']=S(b,u)
    D['perm']=dict(p=ex[nm]['p'],med=ex[nm]['perm_med'],p95=ex[nm]['perm95'],ci=list(ex[nm]['ci']))
    D['window']=[str(IDX[u.s0].date()),str(IDX[u.s1].date())]
    J[nm]=D
# old configs re-check (sector)
old=[]
ref=pd.read_csv('/home/claude/chk/research-results-10y.csv',encoding='utf-8-sig')
for (ma,w,cf,pol,exn,lab) in [('D50',0,'touch','L20','H5','MA50D chạm · L20 · giữ 5'),('W20',0.5,'touch','L20','H5','MA20W ±0,5 chạm · L20 · giữ 5'),('W20',0.5,'hold','L20','H5','MA20W ±0,5 giữ · L20 · giữ 5'),('W20',0.5,'reclaim','L20','H5','MA20W ±0,5 lấy lại · L20 · giữ 5')]:
    x=G[(G.univ=='sector')&(G.ma==ma)&(G.w==w)&(G.conf==cf)&(G.pol==pol)&(G.exit==exn)].iloc[0]
    rr=ref[(ref.ma==ma)&(ref.width_atr==w)&(ref.confirmation==cf)&(ref.policy==pol)&(ref.hold==5)].iloc[0]
    old.append(dict(lab=lab,pf10=rr.all_pf,n10=int(rr.all_n),pf27=x.pf,n27=int(x.n),pre16=x.pre16_pf,p1=x.p1_pf,p3=x.p3_pf,d3=x.drop3))
J['old']=old
J['primary']=dict(n=len(T),pf=pf(T.r.values),legs_ov=110,legs=504,bask_ov=73,bask=170,prim_in=155)
J['samewin']=ex['sector_samewin']
J['spy_bh']={nm:dict(cagr=float((u.C[u.s1,0]/u.C[u.s0,0])**(365.25/(IDX[u.s1]-IDX[u.s0]).days)-1),mdd=float((u.C[u.s0:u.s1+1,0]/np.maximum.accumulate(u.C[u.s0:u.s1+1,0])-1).min())) for nm,u in US.items()}
def clean(o):
    if isinstance(o,dict): return {k:clean(v) for k,v in o.items()}
    if isinstance(o,(list,tuple)): return [clean(v) for v in o]
    if isinstance(o,(np.floating,float)): return None if (o is None or np.isnan(o) or np.isinf(o)) else round(float(o),4)
    if isinstance(o,(np.integer,)): return int(o)
    if isinstance(o,np.bool_): return bool(o)
    return o
json.dump(clean(J),open('report.json','w'),ensure_ascii=False)
import pprint
for nm in ['sector','sub']:
    print(nm,'main',{k:(round(v,3) if isinstance(v,float) else v) for k,v in J[nm]['main'].items()})
    print(pd.DataFrame(J[nm]['hold'])[['exit','n','pf','wr','avg','drop3','spy_pf','base','cagr','mdd','expo']].round(3).to_string())
    print(pd.DataFrame(J[nm]['entry'])[['conf','exit','n','pf','drop3','p1','p2','p3','worst','mae','maew']].round(3).to_string())
    print(pd.DataFrame(J[nm]['policy']).round(3).to_string())
    print(pd.DataFrame(J[nm]['depth']).round(2).to_string())
print(pd.DataFrame(J['old']).round(2).to_string())
