import sys, time, pickle; sys.path.insert(0,'/home/claude/bt')
from study2 import *
MAS=[('D',10),('D',20),('D',50),('D',200),('W',10),('W',20),('W',50),('W',200)]
W=[0,0.25,0.5,0.75]; CONF=['touch','hold','reclaim']
POLS=['L4K','L20','L60','L250','L250T','SPY','B3']
SIG={(f'{k}{n}',w,cf):E.signals(PSPY,k,n,w,cf) for k,n in MAS for w in W for cf in CONF}
res={}
for name,mem,me in [('sector',SECT,9),('sub',SUB,10)]:
  u=U(mem,me); t0=time.time()
  print(name,'window',IDX[u.s0].date(),IDX[u.s1].date())
  BAS={}
  for key,sig in SIG.items():
    for pol in POLS:
      for ex in EXITS: BAS[key+(pol,ex)]=u.run(sig,pol,ex)
  print('det',time.time()-t0)
  RAND={}
  for key,sig in SIG.items():
    for ex in EXITS:
      runs=[u.run(sig,'RAND',ex,np.random.default_rng(1000+k)) for k in range(30)]
      RAND[key+(ex,)]=(np.nanmedian([pf([b['r'] for b in x]) for x in runs]), np.nanmedian([np.mean([b['r'] for b in x]) for x in runs if x]))
  print('rand',time.time()-t0)
  BASE={}
  for pol in POLS+['RAND']:
    rnd=np.random.default_rng(5)
    for ex in EXITS:
      rr=[(t,u.basket(t,pol,ex,rnd)) for t in range(u.s0,u.s1)]
      rr=[(t,b['r']) for t,b in rr if b]
      tt=np.array([a for a,_ in rr]); a=np.array([b for _,b in rr]); up=u.spy_up[tt]
      BASE[(pol,ex)]=dict(pf=pf(a),avg=a.mean(),pf_up=pf(a[up]),avg_up=a[up].mean(),pf_dn=pf(a[~up]),avg_dn=a[~up].mean(),t=tt,r=a)
  print('base',time.time()-t0)
  res[name]=dict(BAS=BAS,RAND=RAND,BASE=BASE,s0=u.s0,s1=u.s1)
pickle.dump((SIG,res),open('res2.pkl','wb'))
